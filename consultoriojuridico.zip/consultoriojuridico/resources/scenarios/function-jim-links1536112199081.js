(function(window, undefined) {

  var jimLinks = {
    "d12245cc-1680-458d-89dd-4f0d7fb22724" : {
      "Button_1" : [
        "216d6935-21a6-4fb4-b569-22adb1f8abe0"
      ]
    },
    "43958b33-a92e-4d75-91f2-32c725e3edcc" : {
      "Button_3" : [
        "43958b33-a92e-4d75-91f2-32c725e3edcc"
      ],
      "Button_4" : [
        "43958b33-a92e-4d75-91f2-32c725e3edcc"
      ],
      "Button_1" : [
        "216d6935-21a6-4fb4-b569-22adb1f8abe0"
      ]
    },
    "216d6935-21a6-4fb4-b569-22adb1f8abe0" : {
      "Button_1" : [
        "d12245cc-1680-458d-89dd-4f0d7fb22724"
      ],
      "Button_2" : [
        "43958b33-a92e-4d75-91f2-32c725e3edcc"
      ]
    }    
  }

  window.jimLinks = jimLinks;
})(window);